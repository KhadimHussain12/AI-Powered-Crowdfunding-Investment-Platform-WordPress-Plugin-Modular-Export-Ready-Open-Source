Crowdfund Platform Enhanced - includes admin/frontend CSV export and print-to-PDF.
Shortcode: [crowdfund_platform]

Install: Upload ZIP in WP Plugins > Add New > Upload Plugin.