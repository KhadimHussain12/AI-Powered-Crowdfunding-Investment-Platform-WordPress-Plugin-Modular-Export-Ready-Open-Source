(function($){
    function notify(msg){ alert(msg); }

    function loadDeals(){
        $.post(CF_Ajax.ajax_url, {action:'cf_get_deals', nonce:CF_Ajax.nonce}, function(resp){
            if(resp.success){
                var html='';
                resp.data.forEach(function(d){
                    var score = scoreDeal(d);
                    html += '<div class="cf-deal-card">';
                    html += '<strong>'+escapeHtml(d.title)+'</strong><div>'+escapeHtml(d.location)+' — Target: $'+Number(d.target_amount).toLocaleString()+'</div>';
                    html += '<div>Min: $'+Number(d.min_investment).toLocaleString()+' | Yield: '+escapeHtml(d.yield_estimate)+' | LTV: '+escapeHtml(d.ltv)+'%</div>';
                    html += '<div>Score: '+score.label+' ('+score.score+')</div>';
                    html += '</div>';
                });
                $('#cf_deals_list').html(html);
            }
        });
    }

    function scoreDeal(d){
        var score = 0;
        var yield = parseFloat(String(d.yield_estimate).replace('%','')) || 0;
        if(yield>=8) score += 40;
        else if(yield>=6) score += 30;
        else score += 10;
        var ltv = parseFloat(d.ltv) || 0;
        if(ltv<=65) score += 30;
        else if(ltv<=75) score += 10;
        var target = parseFloat(d.target_amount) || 0;
        if(target<=200000) score += 10;
        else score += 5;
        var label = 'C';
        if(score>=70) label='A';
        else if(score>=45) label='B';
        return {score:score, label:label};
    }

    function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

    $('#cf_draft').on('click', function(){
        var t = $('#cf_title').val();
        var loc = $('#cf_location').val();
        var target = $('#cf_target').val();
        var min = $('#cf_min').val();
        var yield = $('#cf_yield').val();
        var ltv = $('#cf_ltv').val();
        var desc = $('#cf_description').val();
        var template = localStorage.getItem('cf_template') || 'Introducing {{title}} in {{location}} — target raise ${{target_amount}}. Minimum investment ${{min_investment}}. Estimated yield: {{yield_estimate}}. Overview: {{description}}';
        var filled = template.replace(/{{title}}/g, t||'Untitled').replace(/{{location}}/g, loc||'—').replace(/{{target_amount}}/g, Number(target||0).toLocaleString()).replace(/{{min_investment}}/g, Number(min||0).toLocaleString()).replace(/{{yield_estimate}}/g, yield||'N/A').replace(/{{description}}/g, desc||'');
        $('#cf_draft_preview').text(filled);
    });

    $('#cf_create').on('click', function(){
        var data = {
            action:'cf_create_deal',
            nonce: CF_Ajax.nonce,
            title: $('#cf_title').val(),
            location: $('#cf_location').val(),
            target: $('#cf_target').val(),
            min: $('#cf_min').val(),
            yield: $('#cf_yield').val(),
            ltv: $('#cf_ltv').val(),
            description: $('#cf_description').val()
        };
        $.post(CF_Ajax.ajax_url, data, function(resp){
            if(resp.success){ notify('Deal created'); loadDeals(); }
            else notify('Error creating deal');
        });
    });

    $('#inv_signup').on('click', function(){
        var data = {
            action:'cf_create_investor',
            nonce: CF_Ajax.nonce,
            name: $('#inv_name').val(),
            email: $('#inv_email').val(),
            risk: $('#inv_risk').val(),
            regions: $('#inv_regions').val(),
            min: $('#inv_min').val(),
            max: $('#inv_max').val()
        };
        $.post(CF_Ajax.ajax_url, data, function(resp){
            if(resp.success){ notify('Signed up as investor'); }
            else notify('Error signing up');
        });
    });

    $('#cf_export_csv').on('click', function(){
        // request deals then generate client-side CSV
        $.post(CF_Ajax.ajax_url, {action:'cf_get_deals', nonce:CF_Ajax.nonce}, function(resp){
            if(resp.success){
                var csv = 'Title,Location,Target,Min,Yield,LTV\\n';
                resp.data.forEach(function(d){ csv += '\"'+d.title.replace(/\"/g,'\"\"')+'\",\"'+d.location+'\",\"'+d.target_amount+'\",\"'+d.min_investment+'\",\"'+d.yield_estimate+'\",\"'+d.ltv+'\"\\n'; });
                downloadFile(csv, 'deals_frontend.csv', 'text/csv');
            }
        });
    });

    $('#cf_export_pdf').on('click', function(){
        // prepare printable page
        $.post(CF_Ajax.ajax_url, {action:'cf_get_deals', nonce:CF_Ajax.nonce}, function(resp){
            if(resp.success){
                var html = '<h2>Deals</h2>';
                resp.data.forEach(function(d){ html += '<div><h3>'+escapeHtml(d.title)+'</h3><div>'+escapeHtml(d.location)+' — $'+Number(d.target_amount).toLocaleString()+'</div><p>'+escapeHtml(d.description||'')+'</p></div><hr/>'; });
                openPrintWindow(html, 'Deals Report');
            }
        });
    });

    function downloadFile(content, filename, mime){
        var blob = new Blob([content], {type:mime||'application/octet-stream'});
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click();
        setTimeout(function(){ URL.revokeObjectURL(url); a.remove(); }, 1000);
    }

    function openPrintWindow(htmlContent, title){
        var w = window.open('', '_blank', 'width=900,height=700');
        var doc = w.document;
        doc.open();
        doc.write('<html><head><title>'+escapeHtml(title)+'</title>');
        doc.write('<style>body{font-family:Arial,Helvetica,sans-serif;padding:20px}h2{margin-top:0} hr{margin:16px 0}</style>');
        doc.write('</head><body>');
        doc.write('<h1>'+escapeHtml(title)+'</h1>');
        doc.write(htmlContent);
        doc.write('</body></html>');
        doc.close();
        setTimeout(function(){ w.focus(); w.print(); }, 500);
    }

    function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

    // initial load
    $(document).ready(function(){ loadDeals(); });
})(jQuery);